package ch04;

public class Array {
	public static void main(String[] args) {

		char a[] = { '��', '��', '��', '��'};

		System.out.print(a[0]);
		System.out.print(a[1]);
		System.out.print(a[2]);
		System.out.print(a[3]);
		
	}
}
