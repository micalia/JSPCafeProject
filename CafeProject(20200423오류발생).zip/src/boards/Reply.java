package boards;

public class Reply {
	private int b_id;
	private int bundle;
	private int num;
	private String reply;
	private String time;
	private String nick;
	private String user_id;
	private String rec_nick;
	private String rec_user_id;
	
	public int getB_id() {
		return b_id;
	}
	public void setB_id(int b_id) {
		this.b_id = b_id;
	}
	public int getBundle() {
		return bundle;
	}
	public void setBundle(int bundle) {
		this.bundle = bundle;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getReply() {
		return reply;
	}
	public void setReply(String reply) {
		this.reply = reply;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getRec_nick() {
		return rec_nick;
	}
	public void setRec_nick(String rec_nick) {
		this.rec_nick = rec_nick;
	}
	public String getRec_user_id() {
		return rec_user_id;
	}
	public void setRec_user_id(String rec_user_id) {
		this.rec_user_id = rec_user_id;
	}
	
}
